const { cac, CAC, Command } = require('./dist/index')

// For backwards compatibility
module.exports = cac

Object.assign(module.exports, {
  default: cac,
  cac,
  CAC,
  Command,
})
