# Installation
> `npm install --save @types/mdast`

# Summary
This package contains type definitions for mdast (https://github.com/syntax-tree/mdast).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mdast.

### Additional Details
 * Last updated: Tue, 14 May 2024 07:35:36 GMT
 * Dependencies: [@types/unist](https://npmjs.com/package/@types/unist)

# Credits
These definitions were written by [Christian Murphy](https://github.com/ChristianMurphy), [Jun Lu](https://github.com/lujun2), [Remco Haszing](https://github.com/remcohaszing), [Titus Wormer](https://github.com/wooorm), and [Remco Haszing](https://github.com/remcohaszing).
