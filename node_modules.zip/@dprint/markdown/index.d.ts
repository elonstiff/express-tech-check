/** Gets an absolute path to the Wasm module. */
export function getPath(): string;
