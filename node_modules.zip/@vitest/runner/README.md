# @vitest/runner

Vitest mechanism to collect and run tasks.

[GitHub](https://github.com/vitest-dev/vitest) | [Documentation](https://vitest.dev/advanced/runner)
