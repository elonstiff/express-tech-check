import builtinModules from './builtin-modules.json' with {type: 'json'};

export default builtinModules;
