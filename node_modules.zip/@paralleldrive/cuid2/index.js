const { createId, init, getConstants, isCuid } = require("./src/index");

module.exports.createId = createId;
module.exports.init = init;
module.exports.getConstants = getConstants;
module.exports.isCuid = isCuid;
