export declare const CWD: string;
export declare const cjsRequire: NodeJS.Require;
export declare const EXTENSIONS: string[];
